import { Component } from '@angular/core';
import {FormBuilder,FormGroup,Validators, FormControl, MinLengthValidator} from '@angular/forms'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FormDesginingUsingBootstrap';

  public Data1:any;
  public Data2:any;
  public Data3:any;
  public Data4:any;
  public Data5:any;
}
