import { Component, OnInit,Injectable } from '@angular/core';
import {NgbCalendar, NgbDate, NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-bug-info',
  templateUrl: './bug-info.component.html',
  styleUrls: ['./bug-info.component.css']
})
export class BugInfoComponent  {

  constructor(){}
  //public const date = new Date();

  public topic = [ 'Hard', 'Medium','Low'  ];
  public Description ="";

  getDate(){
    const date = new Date();
    return date;
}
  }




