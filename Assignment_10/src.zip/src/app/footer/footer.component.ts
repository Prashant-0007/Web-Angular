import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  constructor() { }

  public Name :any;
  public LastName:any;
  public EmailAddress :any;
  public Impact:any;
  public Description :any;

  public str1 : any;
  public str2 : any;
  public str3 : any;
  public str4 : any;
  public str5 : any;

  public Fun()
  {
    this.str1 = this.Name;
    this.str2 = this.LastName;
    this.str3 = this.EmailAddress;
    this.str4 = this.Impact;
    this.str5 = this.Description;

  }

  ngOnInit(): void {
  }

}
