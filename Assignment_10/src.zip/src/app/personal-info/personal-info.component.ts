import { Component, OnInit,EventEmitter,Output } from '@angular/core';


@Component({
  selector: 'app-personal-info',
  templateUrl: './personal-info.component.html',
  styleUrls: ['./personal-info.component.css']
})
export class PersonalInfoComponent implements OnInit {

  constructor() { }
  public Name = "";
  public EmailAddress = "";
  public LastName = "";

  @Output() public Myevent = new EventEmitter();  //direct janar nahi message tar laser ahe haan ani sadha obj nahi mhanun @output lihala across the component output pathavayacha

  // flow step 2
  public fun()
  {
    /*this mnje hya class cha obj ahe
    emit message pathavayacha asel tar.. */
    this.Myevent.emit(this.Name); // Or this.Myevent.emit("Hello, Parent");
    this.Myevent.emit(this.EmailAddress);
    this.Myevent.emit(this.LastName);
  }

  ngOnInit(): void {
  }

}
