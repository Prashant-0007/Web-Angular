import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TechnologiesComponent } from './technologies/technologies.component';
import { BooksComponent } from './books/books.component';
import { NavigationComponent } from './navigation/navigation.component';
import { InvalidateComponentComponent } from './invalidate-component/invalidate-component.component';

//chota 'routes' is array of Motha 'Routes' datatype
const routes: Routes = [
  {path:'technologies',component:TechnologiesComponent},
  {path:'navigation',component:NavigationComponent},
  {path:'books',component:BooksComponent},
  {path:'**',component:InvalidateComponentComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
