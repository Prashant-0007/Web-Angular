import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvalidateComponentComponent } from './invalidate-component.component';

describe('InvalidateComponentComponent', () => {
  let component: InvalidateComponentComponent;
  let fixture: ComponentFixture<InvalidateComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InvalidateComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InvalidateComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
