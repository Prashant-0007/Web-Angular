import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invalidate-component',
  templateUrl: './invalidate-component.component.html',
  styleUrls: ['./invalidate-component.component.css']
})
export class InvalidateComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
