import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myAdd'
})
export class MyAddPipe implements PipeTransform {

  public sum : number = 0;
  transform(value: number, num: number): any {

      this.sum= value + num;
      return this.sum;

  }

}
