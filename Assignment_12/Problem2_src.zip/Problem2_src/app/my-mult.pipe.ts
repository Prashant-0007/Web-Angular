import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myMult'
})
export class MyMultPipe implements PipeTransform {

  public mult : number = 1;
  transform(value: number, no2:number): any {

      this.mult = value * no2;
      return this.mult;
  }

}
