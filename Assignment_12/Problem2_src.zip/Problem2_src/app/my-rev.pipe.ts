import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myRev'
})
export class MyRevPipe implements PipeTransform {

  transform(value:unknown,string1:string): any {

    //To hold the reverse string
    //<h1>{{Name|myRev}}</h1>
    var temp : string="";

    if(string1 =="Marvellous")
    {
      temp ="suollevraM";
    }

    return temp;


  }

}
