import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellousChk'
})
export class MarvellousChkPipe implements PipeTransform {


  transform(value: number, Param : string): any {

    var count : number =0;
    var str : string = "";
    console.log("In transform method");
    var i : number =2;
    if(Param === "Prime"){
      for(var i =2;i<value;i++){
        if( value % i == 0) {
          count++}

      }

      str = ((count >= 1)?"It Is Prime Not Number":"It IsPrime Number");
    }
    else if(Param === "Perfect") {

    var sum = 1;

    for (var i = 2; i * i <= value; i++)
    {
        if (value % i==0)
        {
            if(i * i != value)
                sum = sum + i + value / i;
            else
                sum = sum + i;
        }
    }
    // If sum of divisors is equal to
    // value, then n is a perfect number

    str =(sum==value && value !=1)?"It Is Perfect Nuumber":"It Is Not Perfect Number";
    }
    else if(Param === "Even") {
        str = (value%2==0)?"It Is Even Number":"It Is Not Even Number";
    }
    else if(Param === "Odd") {
      str = (value%2==1)?"It Is Odd Number":"It Is Not Odd Number";
    }

    return str;
  }


}
