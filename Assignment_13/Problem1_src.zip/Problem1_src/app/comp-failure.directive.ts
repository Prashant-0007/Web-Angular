import { Directive,ElementRef,HostListener } from '@angular/core';

@Directive({
  selector: '[appCompFailure]'
})
export class CompFailureDirective {

 //Note: Ekhadya gosti karata class asel tar tyat dependency injection karu shkto..
 constructor(private eobj:ElementRef)
 {

 }
 @HostListener('mouseenter')onmouseenter()
 {
   //mnje html var gelat tumhi..
   this.eobj.nativeElement.style.background='red';
 }
 @HostListener('mouseleave')onmouseleave()
 {
   this.eobj.nativeElement.style.background='black';
 }


}
