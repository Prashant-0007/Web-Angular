import { Directive,ElementRef,HostListener } from '@angular/core';

@Directive({
  selector: '[appCompSuccess]'
})
export class CompSuccessDirective {

    //Note: Ekhadya gosti karata class asel tar tyat dependency injection karu shkto..
    constructor(private eobj:ElementRef)
    {

    }
    @HostListener('mouseenter')onmouseenter()
    {
      //mnje html var gelat tumhi..
      this.eobj.nativeElement.style.background='green';
    }
    @HostListener('mouseleave')onmouseleave()
    {
      this.eobj.nativeElement.style.background='red';
    }


}
