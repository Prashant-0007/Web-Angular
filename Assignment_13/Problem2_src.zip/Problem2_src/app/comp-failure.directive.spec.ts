import { CompFailureDirective } from './comp-failure.directive';

describe('CompFailureDirective', () => {
  it('should create an instance', () => {
    const directive = new CompFailureDirective();
    expect(directive).toBeTruthy();
  });
});
