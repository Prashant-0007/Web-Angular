import { Directive,ElementRef,HostListener } from '@angular/core';

@Directive({
  selector: '[appCompSuccess]',
  host: {
    '[style.background-color]': '"yellow"',
  }
})
export class CompSuccessDirective {

    //Note: Ekhadya gosti karata class asel tar tyat dependency injection karu shkto..
    constructor(private eobj:ElementRef) {

    }


}
