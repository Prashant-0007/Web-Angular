import { Directive,ElementRef,HostListener } from '@angular/core';

@Directive({
  selector: '[appCustomStyle]',
  host: {
    '[style.background-color]': '"yellow"',
  }
})
export class CustomStyleDirective {

  constructor(private eobj:ElementRef) { }

}
