import { Component } from '@angular/core';
// import classes which are required for reactive forms
import {FormGroup,FormControl} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'DesginDemo';

  MyForm = new FormGroup(
    {
      Name : new FormControl('Prashant'),
      LastName : new FormControl(''),
      Phone : new FormControl(''),
      Address : new FormControl('')

    });


}
