import { Component } from '@angular/core';
// import classes which are required for reactive forms
import {FormGroup,FormControl, FormBuilder,Validators,MinLengthValidator} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'DesginDemo';
  constructor(public obj: FormBuilder){}

  MyForm = this.obj.group(
    {
      Name : ['', [Validators.required, Validators.minLength(5)] ],
      LastName : [],
      Phone : ['', [Validators.required, Validators.minLength(10)]],
      EmailId : ['',Validators.required],
      City : ['',[Validators.required, Validators.minLength(5)]],
      State : [''],
      zipcode : ['',[Validators.required, Validators.minLength(5)]],
      comments : ['',[Validators.required, Validators.minLength(30)]]
    });

    SetData()
  {
    this.MyForm.setValue(
      {
        Name : 'Prashant',
        LastName : 'abcd',
        Phone : '',
        EmailId : '',
        City : '',
        State : '',
        zipcode : '',
        Comments : ''

      }
    )
  }

}
