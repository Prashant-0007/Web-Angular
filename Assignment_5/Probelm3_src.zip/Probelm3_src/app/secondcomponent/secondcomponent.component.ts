import { Component, OnInit,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-secondcomponent',
  templateUrl: './secondcomponent.component.html',
  styleUrls: ['./secondcomponent.component.css']
})
export class SecondcomponentComponent
{

  @Output() public Myevent = new EventEmitter();  //direct janar nahi message tar laser ahe haan ani sadha obj nahi mhanun @output lihala across the component output pathavayacha
  public Message = "Hello, FirstComponent Rendering From You..."; // Jo message pathavayacha ahe to ekde ahe...

  // flow step
  public SendMessage()
  {
    /*this mnje hya class cha obj ahe
    emit message pathavayacha asel tar.. */
    this.Myevent.emit(this.Message); // Or this.Myevent.emit("Hello, Parent");

}
}
