import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-firstcomp',
  templateUrl: './firstcomp.component.html',
  styleUrls: ['./firstcomp.component.css']
})

export class FirstcompComponent
{

  @Output() public Myevent = new EventEmitter();  //direct janar nahi message tar laser ahe haan ani sadha obj nahi mhanun @output lihala across the component output pathavayacha
  public Message = "Hello, Parent From First Component"; // Jo message pathavayacha ahe to ekde ahe...

  // flow step
  public SendMessage()
  {
    /*this mnje hya class cha obj ahe
    emit message pathavayacha asel tar.. */
    this.Myevent.emit(this.Message); // Or this.Myevent.emit("Hello, Parent");

}
}
