import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<h2 class="custom">Hello, Marvellous Infosystems!!</h2>
  <input type="text"
  #box
  (keyup)="getValue(box.value)"
  placeholder="Enter Name"
  name="name"
  />
  <h2>{{displayVal}}</h2>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'IntepolationInlineTemplate';
  public displayVal : string = "";

  public getValue(value : any) {

    this.displayVal=value;
  }

}
