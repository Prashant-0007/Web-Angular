import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-comp',
  templateUrl: './new-comp.component.html',
  styleUrls: ['./new-comp.component.css']
})

export class NewCompComponent
{

  constructor()
  {

  }
  public Name :any;
  public value:any;

  public methodProperty(value:any):any
  {
    (this.value==String)
        this.value.toLowerCase( );
  }

  public str :any;
  public str1 = "Marvellous";
  public Fun()
  {
    this.str = this.Name;
    console.log("Lowercase String is : "+this.str.toLowerCase( ));
    console.log("Uppercase String is : "+this.str.toUpperCase( ));
    console.log("Concatenated String is : "+this.str1.concat(this.str.toString()));

  }



}
