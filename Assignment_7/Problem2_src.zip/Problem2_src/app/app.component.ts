import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Binding';
  public Data = "Marvellous Infosystems";

  public fun(Data:any)
  {
    return this.Data=Data;
  }

}
