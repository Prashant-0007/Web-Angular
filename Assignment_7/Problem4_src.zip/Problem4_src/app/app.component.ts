import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Binding';
  public str: string = "Marvellous Infosystems";



  public gun() : any
  {
    console.log("To Lower case string is : "+this.str.toLowerCase());
  }
  public fun() : any
  {
    console.log("To Upper case string is : "+this.str.toUpperCase());
  }

}
