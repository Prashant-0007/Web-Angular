import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Binding';
  public text: string = "Educating for better tommorrow";
  public str : any;


  public fun() : any
  {
    if(this.text === "Educating for better tommorrow") {
      return this.str=this.text;
    } else {
      this.str ="Marvellous Infosystems";
      return this.str ;
    }

}
}
