import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-firstcomp',
  templateUrl: './firstcomp.component.html',
  styleUrls: ['./firstcomp.component.css']
})
export class FirstcompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  public str ="This is text from first component123";
}
