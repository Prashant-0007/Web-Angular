import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'InterCompCommunication';

  constructor() {

  }
  public value:any;
  public getData(value: any) {

    console.log(value);
  }


}
