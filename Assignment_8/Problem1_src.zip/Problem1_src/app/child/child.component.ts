import { Component, OnInit,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  @Output() public Myevent = new EventEmitter();  //direct janar nahi message tar laser ahe haan ani sadha obj nahi mhanun @output lihala across the component output pathavayacha
  public Message = "Hello, Parent..."; // Jo message pathavayacha ahe to ekde ahe...

  // flow step 2
  public SendMessage()
  {
    /*this mnje hya class cha obj ahe
    emit message pathavayacha asel tar.. */
    this.Myevent.emit(this.Message); // Or this.Myevent.emit("Hello, Parent");
  }
}

