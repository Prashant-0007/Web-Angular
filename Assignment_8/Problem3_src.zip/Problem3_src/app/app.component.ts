import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'InterCompCommunication';

  constructor() {

  }
  public Name : any;

  public len : any = 0;


public str :any;
public Fun()
{
  this.str = this.Name;
  this.len=this.str.length;

}



}
