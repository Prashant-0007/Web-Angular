

export interface IAddSub
 {

 no1 :number,
 no2 : number
}
