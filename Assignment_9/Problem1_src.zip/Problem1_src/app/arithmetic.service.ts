import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IAddSub } from './AddSub';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ArithmeticService {

  constructor(private _obj:HttpClient) { }
  //Connection to server
  private URL ='./assets/Data/AddSub.json';

  public add(value1:number,value2:number): number
  {
    return (value1+ value2);

  }
  public Sub(value1:number,value2:number): number
  {
    return (value1-value2);

  }

}
