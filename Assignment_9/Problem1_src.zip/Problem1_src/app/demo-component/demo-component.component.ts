import { Component, OnInit } from '@angular/core';
import { ArithmeticService } from './../arithmetic.service';
import {HttpClientModule}from'@angular/common/http';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-demo-component',
  template :`
  <h1>Inside Demo-Component</h1>
<h2>Arithmetic Service Rendering</h2>
<h2 >Addition is {{sum}}</h2>
<h2 >Substraction is {{sub}}</h2>
  `
})
export class DemoComponentComponent implements OnInit {

  constructor(private _arithService:ArithmeticService) { }
  public sum:any;
  public sub :any;

  ngOnInit(): void {
    this.sum = this._arithService.add(10,20);
    this.sub = this._arithService.Sub(10,20);

  }

}
