import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';

@Component({
  selector: 'app-child1',
  template : `
    <h2>Number Service Check Prime Or Not In Child1 Component</h2>
    <h2>Given Number {{num}}</h2>
    <h2>{{str}}</h2>
  `
})
export class Child1Component implements OnInit {

  constructor(private _obj : NumberService) { }
  public num : number = 12;
  public str = "";

  ngOnInit(): void {

    this.str =this._obj.ChkPrime(this.num);
  }

}
