import { Component, OnInit } from '@angular/core';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child2',
  template : `
  <h2>Given String Is : {{name}}</h2>
  <h2>The Capital Lettes In Give String Is : {{count}}</h2>
  `
})
export class Child2Component implements OnInit {

  constructor(private _obj : StringService) { }
  public name = "PrAsHaNtPP";
  public count : number = 0;

  ngOnInit(): void {

    this.count = this._obj.CountCapital(this.name);
  }

}
