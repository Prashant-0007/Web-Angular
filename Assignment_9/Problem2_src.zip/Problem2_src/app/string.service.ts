import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService {

  constructor() { }

  public CountCapital(str : String) : number{

    var i = 0;
    var j = 0;
    var count = 0;
    var caps = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    for(i ; i < str.length; i++)
    {
       for(j = 0; j<caps.length;j++)
       {
        if(str.charAt(i) === caps.charAt(j))
        {
          count++;
        }
       }
    }

    return count;
  }
}
