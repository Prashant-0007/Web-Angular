import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';
import { StringService } from '../string.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-child1',
  template : `

    <h2>Number Service Check Prime Or Not In Child1 Component</h2>
    <h2>Please Enter Only Integers</h2>
    <input type="text" [(ngModel)]="value"/>
    <h2>Entered Value Is :{{value}} </h2>
    <h2>To Save above value please click on submit</h2>
    <button (click)="Fun()">
      SUBMIT
    </button>
    <h2>{{str}}</h2>
    <h2>Given String is : {{name}}</h2>
    <h2> Capital Letters In Given String is : {{count}}</h2>

  `
})
export class Child1Component implements OnInit {

  constructor(private _obj1 : NumberService,private _obj2 : StringService) { }
  public name = "PrAsHaNtPP";
  public count : number = 0;
  public num : number = 0;

  public str :any;
  public value : number = 0;
  public Fun()
  {
    this.num = this.value;
    this.str =this._obj1.ChkPrime(this.num);

  }



  ngOnInit(): void {


    this.count = this._obj2.CountCapital(this.name);
  }

}
