import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService {

  constructor() { }
  public str = "";

  public ChkPrime(value : number ) : string
  {
      var i = 2;
      var count = 0
      for(i ; i < value ; i++)
      {
        if(value % i == 0)
          count++
      }
      this.str = (count >= 1)?"Given Number Is Not Prime Number":"Given Numb Is Prime Number";
    return this.str;
  }
}
